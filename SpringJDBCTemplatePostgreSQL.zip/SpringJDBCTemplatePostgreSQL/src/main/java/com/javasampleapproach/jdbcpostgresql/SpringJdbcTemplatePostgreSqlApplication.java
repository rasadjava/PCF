package com.javasampleapproach.jdbcpostgresql;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import com.javasampleapproach.jdbcpostgresql.service.EmployeeService;

@Configuration
@SpringBootApplication
@ComponentScan("com.sample.springboot.webservice, com.javasampleapproach.jdbcpostgresql.service.impl, com.javasampleapproach.jdbcpostgresql.dao.impl")
public class SpringJdbcTemplatePostgreSqlApplication {

	@Autowired
	EmployeeService cusService;

	public static void main(String[] args) {
		SpringApplication.run(SpringJdbcTemplatePostgreSqlApplication.class, args);
		
		System.out.println("#######################################");
		System.out.println("Application Started!!!");
		System.out.println("#######################################");
	}
}
