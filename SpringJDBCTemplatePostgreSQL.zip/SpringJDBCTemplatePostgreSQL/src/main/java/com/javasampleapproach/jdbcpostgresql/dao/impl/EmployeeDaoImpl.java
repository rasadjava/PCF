package com.javasampleapproach.jdbcpostgresql.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.javasampleapproach.jdbcpostgresql.dao.EmployeeDao;
import com.javasampleapproach.jdbcpostgresql.model.Employee;

@Repository
public class EmployeeDaoImpl extends JdbcDaoSupport implements EmployeeDao {

	@Autowired
	DataSource dataSource;

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

	@Override
	public String dynamicInsert(int id, String name, int age) {
		String sql = "INSERT INTO Employee " + "(CUST_ID, NAME, AGE) VALUES (?, ?, ?)";
		getJdbcTemplate().update(sql, new Object[] { id, name, age });
		return null;
	}
	
	@Override
	public int deleteEmp(int id) {
		String sql = "DELETE FROM EMPLOYEE WHERE CUST_ID = ?";
		int i = getJdbcTemplate().update(sql, new Object[] { id });
		return i;
	}
	
	@Override
	public int updateEmp(int id, String name, int age) {
		String sql = "UPDATE EMPLOYEE SET AGE = ? , NAME = ? WHERE CUST_ID = ?";
		int i = getJdbcTemplate().update(sql, new Object[] { age, name, id });
		return i;
	}

	public List<Employee> loadAllCustomer() {
		String sql = "SELECT * FROM Employee";
		List<Employee> result = new ArrayList<Employee>();
		try {
			List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql);
			for (Map<String, Object> row : rows) {
				Employee cus = new Employee();
				cus.setEmpId((Integer) row.get("cust_id"));
				cus.setName((String) row.get("name"));
				cus.setAge((Integer) row.get("age"));
				result.add(cus);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return result;
	}

	@Override
	public Employee findCustomerById(int cust_id) {
		String sql = "SELECT * FROM Employee WHERE CUST_ID = ?";
		return (Employee) getJdbcTemplate().queryForObject(sql, new Object[] { cust_id }, new RowMapper<Employee>() {
			@Override
			public Employee mapRow(ResultSet rs, int rwNumber) throws SQLException {
				Employee cust = new Employee();
				cust.setEmpId(rs.getInt("cust_id"));
				cust.setName(rs.getString("name"));
				cust.setAge(rs.getInt("age"));
				return cust;
			}
		});
	}

	@Override
	public String findNameById(int cust_id) {
		String sql = "SELECT name FROM Employee WHERE cust_id = ?";
		return getJdbcTemplate().queryForObject(sql, new Object[] { cust_id }, String.class);
	}

	@Override
	public int getTotalNumberCustomer() {
		String sql = "SELECT Count(*) FROM Employee";
		int total = getJdbcTemplate().queryForObject(sql, Integer.class);
		return total;
	}

}
