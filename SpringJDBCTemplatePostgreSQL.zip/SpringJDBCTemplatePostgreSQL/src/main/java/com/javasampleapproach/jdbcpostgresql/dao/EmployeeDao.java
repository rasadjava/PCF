package com.javasampleapproach.jdbcpostgresql.dao;

import java.util.List;
import com.javasampleapproach.jdbcpostgresql.model.Employee;

public interface EmployeeDao {
	String dynamicInsert(int id, String name, int age);
	int deleteEmp(int id);
	int updateEmp(int id, String name, int age);
	List<Employee> loadAllCustomer();
	Employee findCustomerById(int cust_id);
	String findNameById(int cust_id);
	int getTotalNumberCustomer();
}
