package com.javasampleapproach.jdbcpostgresql.service;

import java.util.List;

import com.javasampleapproach.jdbcpostgresql.model.Employee;

public interface EmployeeService {
	String dynamicInsert(int id, String name, int age);
	int deleteEmp(int id);
	int updateEmp(int id, String name, int age);
	List<Employee> loadAllCustomer();
	Employee getCustomerById(int cust_id);
	void getCustomerNameById(int cust_id);
	void getTotalNumerCustomer();
}
