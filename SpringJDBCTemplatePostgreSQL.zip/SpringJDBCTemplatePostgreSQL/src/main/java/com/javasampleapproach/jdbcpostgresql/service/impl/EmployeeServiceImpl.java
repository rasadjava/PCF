package com.javasampleapproach.jdbcpostgresql.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javasampleapproach.jdbcpostgresql.dao.EmployeeDao;
import com.javasampleapproach.jdbcpostgresql.model.Employee;
import com.javasampleapproach.jdbcpostgresql.service.EmployeeService;


@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired EmployeeDao customerDao;
	
	public List<Employee> loadAllCustomer(){
		List<Employee> listCust = null;
		try {
		listCust = customerDao.loadAllCustomer();
		for(Employee cus: listCust){
			System.out.println(cus.toString());
		}
		}catch(Exception e) {
			System.out.println(e);
		}
		return listCust;
	}

	@Override
	public Employee getCustomerById(int cust_id) {
		Employee cust = customerDao.findCustomerById(cust_id);
		System.out.println(cust);
		return cust;
	}

	@Override
	public void getCustomerNameById(int cust_id) {
		String name = customerDao.findNameById(cust_id);
		System.out.println("Customer's name = " + name);
	}

	@Override
	public void getTotalNumerCustomer() {
		int totalNumberCustomer = customerDao.getTotalNumberCustomer();
		System.out.println("Total Number Customer is: " + totalNumberCustomer);
	}
	
	@Override
	public String dynamicInsert(int id, String name, int age) {
		customerDao.dynamicInsert(id, name, age);
		return null;
	}
	
	@Override
	public int deleteEmp(int id) {
		int i = customerDao.deleteEmp(id);
		return i;
	}
	
	@Override
	public int updateEmp(int id, String name, int age) {
		int i = customerDao.updateEmp(id, name, age);
		return i;
	}

}
