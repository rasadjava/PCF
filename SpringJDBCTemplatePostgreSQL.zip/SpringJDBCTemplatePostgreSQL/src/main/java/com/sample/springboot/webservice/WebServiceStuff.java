package com.sample.springboot.webservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.jdbcpostgresql.model.Employee;
import com.javasampleapproach.jdbcpostgresql.service.impl.EmployeeServiceImpl;

@RestController
@RequestMapping("/demo")
public class WebServiceStuff {

	@Autowired
	EmployeeServiceImpl customerServiceImpl = new EmployeeServiceImpl();

	@RequestMapping(value="/AppInfo", method= RequestMethod.GET)
	public StringBuffer sampleWebserviceCall() {
		System.out.println("Sample SpringBoot Application");
		StringBuffer sb = new StringBuffer();
		sb.append("<html><body><table align='center'><tr><td><strong><font color='skyblue'><i>CRUD Operations:</br>\n");
		sb.append("C ==> Create ( Ex: http://localhost:8088/demo/CreateEmp/{id}/{name}/{age} )</br>\n");
		sb.append("R ==> Read ( Ex: http://localhost:8088/demo/ReadEmp )</br>\n");
		sb.append("U ==> Update ( Ex: http://localhost:8088/demo/UpdateEmp/{id}/{name}/{age} )</br>\n");
		sb.append("D ==> Delete ( Ex: http://localhost:8088/demo/DeleteEmp/{id} )</br></i></font>\n</strong></td></tr></table></body></html>");
		return sb;
	}

	@RequestMapping(value="/ReadEmp", produces="text/html", method= RequestMethod.GET)
	public StringBuffer showEmployees() {
		StringBuffer sb = new StringBuffer();
		sb.append("<html><body><table align=\"center\" border=\"2\"><tr bgcolor='skyblue'><td>ID </td><td>Name </td><td>Age </td></tr>");
		System.out.println("Started..");
		try {
			List<Employee> custList = customerServiceImpl.loadAllCustomer();
			if (!custList.isEmpty()) {
				for (Employee c : custList) {
					sb.append("<tr><td> <font color=\"red\">"+c.getEmpId() + "</font></td> <td> " + c.getName() + "</td> <td>" + c.getAge() + "</td></tr>");
					System.out.println(sb); 
				}
			} else {
				sb.append("<h5 align='center'><b><i><font color='red'>No records found, please insert records.. Ex: Hint ### http://localhost:8088/CreateEmp/{id}/{name}/{age} ##</font></i></b></h5>");
				sb.append("</table></body></html>");
				return sb;
			}
		} catch (Exception e) {
			return new StringBuffer("No records found, please insert records..");
		}
		sb.append("</table></body></html>");
		System.out.println("End..");
		return sb;
	}

	@RequestMapping(value = "CreateEmp/{id}/{name}/{age}", method= RequestMethod.GET)
	public String showEmployees(@PathVariable int id, @PathVariable String name, @PathVariable int age) {
		System.out.println("Inserting.....");
		try {
			customerServiceImpl.dynamicInsert(id, name, age);
		} catch (Exception e) {
			System.out.println(e);
			return "Not inserted";
		}
		System.out.println("Insering done.....");
		return "Insertion Successfull";
	}
	
	@RequestMapping("DeleteEmp/{id}")
	public String deleteEmployees(@PathVariable int id) {
		System.out.println("Deleting.....");
		int i;
		String status;
		try {
			 i = customerServiceImpl.deleteEmp(id);
		} catch (Exception e) {
			System.out.println(e);
			return "Error while deleting";
		}
		if(i==0) {
			status = "Not deleted";
		}else {
			status = "Deleted Successfull";
		}
		System.out.println(status);
		return status;
	}
	
	@RequestMapping(value = "UpdateEmp/{id}/{name}/{age}", method= RequestMethod.GET)
	public String updateEmployees(@PathVariable int id, @PathVariable String name, @PathVariable int age) {
		System.out.println("Updating.....");
		int i;
		String status;
		try {
			i = customerServiceImpl.updateEmp(id, name, age);
		} catch (Exception e) {
			System.out.println(e);
			return "Not updated";
		}
		if(i==0) {
			status = "Not updated";
		}else {
			status = "Updated";
		}
		System.out.println(status);
		return status;
	}
}
