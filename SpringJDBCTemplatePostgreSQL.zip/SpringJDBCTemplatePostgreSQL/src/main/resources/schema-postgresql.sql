DROP TABLE IF EXISTS Employee;

CREATE TABLE  Employee (
  CUST_ID smallint  PRIMARY KEY NOT NULL,
  NAME varchar(100) NOT NULL,
  AGE smallint NOT NULL
);
